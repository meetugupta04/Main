import { Component, Input } from "@angular/core";

@Component({
  selector: "assemblyline",
  templateUrl: "./assemblyline.component.html",
  styleUrls: ["./assemblyline.component.scss"]
})
export class AssemblyLineComponent {
  @Input() stages: string[];
  itemValue : string = '';
  itemObj: string = '';
  assemblyArray: string[][];
  constructor() {}

  ngOnInit(){
    this.assemblyArray = this.stages.map(() => []);
  }

  addNewItemObj(event) {
    if (event.key === 'Enter' || event.keyCode === 13) {
      this.assemblyArray[0].unshift(this.itemObj);
      this.itemObj = '';
    }
  }

  shiftNextStage(assemblyItemObj, assemblyItemObjIndex, assemblyArrayIndex) {
    this.assemblyArray[assemblyArrayIndex].splice(assemblyItemObjIndex, 1);
    if (this.assemblyArray.length !== assemblyArrayIndex + 1) {
      this.assemblyArray[assemblyArrayIndex + 1].unshift(assemblyItemObj);
    }
  }

  shiftPreviousStage(event, assemblyItemObj, assemblyItemObjIndex, assemblyArrayIndex) {
    event.preventDefault();
    this.assemblyArray[assemblyArrayIndex].splice(assemblyItemObjIndex, 1);
    if (assemblyArrayIndex !== 0) {
      this.assemblyArray[assemblyArrayIndex - 1].push(assemblyItemObj);
    }
  }
}
