### Candidate written response

---
_After you finish coding, please take 10-15 minutes to briefly describe any usability issues you can identify with the current prototype sketch for this application. Which design decisions do you agree with? Which do you think can be improved? What other ideas or features would be useful to add? While enhancing functionality, how do you plan to manage or improve on the current Enzyme testing suite?_

1. describe any usability issues you can identify with the current prototype sketch for this application
We can use arrows for each stage instead of left and right mouse clicks to move the item to next/previous stage to avoid the click events and also improve the user experience .
2. Which design decisions do you agree with?
We can use key-value pairs of objects instead of two-dimensional array to store the stage and the assembly items.
3. Which do you think can be improved? What other ideas or features would be useful to add? 
The current application does not depict what action the user should perform to move the item to next stage, so for better user experience we can add a tool tip where we can provide necessary details to the user how the application works.
